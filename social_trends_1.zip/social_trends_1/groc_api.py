# groc_api.py
import os
from dotenv import load_dotenv
import praw

load_dotenv()

# Initialize Reddit client (script app)
reddit = praw.Reddit(
    client_id=os.getenv("REDDIT_CLIENT_ID"),
    client_secret=os.getenv("REDDIT_CLIENT_SECRET"),
    user_agent=os.getenv("REDDIT_USER_AGENT"),
)


def fetch_weekly_trending_topics(subreddits=None, limit=10):
    """
    Fetch top weekly trending post titles from given subreddits.
    Returns a list of trending topics.
    """
    if subreddits is None:
        subreddits = ["all"]  # default to Reddit front page

    trending_topics = []

    for subreddit_name in subreddits:
        subreddit = reddit.subreddit(subreddit_name)
        for post in subreddit.top(time_filter="week", limit=limit):
            trending_topics.append({
                "subreddit": subreddit_name,
                "title": post.title,
                "url": post.url,
                "score": post.score,
                "author": str(post.author),
                "num_comments": post.num_comments,
                "created_utc": post.created_utc
            })
    # Sort by score descending
    trending_topics.sort(key=lambda x: x["score"], reverse=True)
    return trending_topics
