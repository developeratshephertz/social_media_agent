# main.py
from fastapi import FastAPI
from groc_api import fetch_weekly_trending_topics

app = FastAPI(title="Reddit Weekly Trending Topics")

@app.get("/health")
def health():
    return {"status": "healthy"}

@app.get("/weekly-trends")
def weekly_trends(subreddits: str = "all", limit: int = 10):
    """
    Fetch weekly trending topics from subreddits.
    - subreddits: comma-separated list, e.g., "all,python,technology"
    """
    try:
        subreddit_list = [s.strip() for s in subreddits.split(",")]
        trends = fetch_weekly_trending_topics(subreddits=subreddit_list, limit=limit)
        return {"success": True, "trends": trends}
    except Exception as e:
        return {"success": False, "error": str(e)}
